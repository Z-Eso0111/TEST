require('dotenv').config();
const express = require('express');
const axios = require('axios');
const { Client, GatewayIntentBits } = require('discord.js');

const app = express();
const port = 3000;

// Discord Bot Config
const bot = new Client({ intents: [GatewayIntentBits.Guilds] });
bot.login(process.env.DISCORD_TOKEN);

bot.on('ready', () => console.log(`Bot is ready! Logged in as ${bot.user.tag}`));

// Static Files
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Routes
app.get('/', (req, res) => {
    res.render('index');
});

app.get('/verify-discord', (req, res) => {
    res.render('verify-discord');
});

app.get('/verify-roblox', async (req, res) => {
    const userId = req.query.userId; // Discord kullanıcı ID'si.
    if (!userId) return res.send('Hata: Kullanıcı ID eksik!');

    // Roblox API çağrısı (Örnek bir kütüphane ya da endpoint kullan)
    const robloxAuthUrl = `https://www.roblox.com/auth/request/authorization?client_id=XXXX`;
    
    try {
        const { data } = await axios.get(robloxAuthUrl); // Bu kısmı kendine göre yapılandır
        const age = data.age; // Örnek: 17 (Gelen veriyi kontrol et)
        
        if (age >= 17) {
            const guildId = "1256309610516713573";
            const roleId = "1324767121888247838";
            
            const guild = bot.guilds.cache.get(guildId);
            const member = guild.members.cache.get(userId);
            
            if (member) {
                await member.roles.add(roleId);
                return res.send('Rol başarıyla verildi!');
            }
            return res.send('Hata: Kullanıcı bulunamadı!');
        } else {
            return res.send('Yaş doğrulama başarısız.');
        }
    } catch (err) {
        console.error(err);
        return res.send('Bir hata oluştu!');
    }
});

// Server Başlatma
app.listen(port, () => console.log(`Sunucu http://localhost:${port} adresinde çalışıyor!`));
